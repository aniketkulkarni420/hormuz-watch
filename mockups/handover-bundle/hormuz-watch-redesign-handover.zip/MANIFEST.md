# Handover bundle manifest

## Docs (read in order)
- README.md
- DESIGN_BRIEF.md
- DESIGN_TOKENS.md
- DO_NOT_REDESIGN.md
- KNOWN_ISSUES.md
- EDGE_CASES.md
- DATA_DICTIONARY.md
- COMPETITIVE_REFERENCES.md

## Screenshots (curated 25)
- screenshots/05-desktop-full.png
- screenshots/01-iphone-se-full.png
- screenshots/03-ipad-full.png
- screenshots/05-desktop-sigtooltip-2.png
- screenshots/01-iphone-se-tab-intel.png
- screenshots/01-iphone-se-signalbar-scrolled.png
- screenshots/05-desktop-cargo-ticker.png
- screenshots/05-desktop-brent-tile.png
- screenshots/05-desktop-verdict-block.png
- screenshots/05-desktop-india-panel.png
- screenshots/05-desktop-conditions.png
- screenshots/05-desktop-xv-list.png
- screenshots/05-desktop-historical.png
- screenshots/05-desktop-unctad.png
- screenshots/05-desktop-cape.png
- screenshots/05-desktop-fertilizer.png
- screenshots/05-desktop-lng.png
- screenshots/05-desktop-currency-tile.png
- screenshots/01-iphone-se-signal-bar.png
- screenshots/01-iphone-se-mobile-tabs.png
- screenshots/01-iphone-se-cargo-ticker.png
- screenshots/01-iphone-se-intel-scroll-3.png
- screenshots/01-iphone-se-footer-discl.png
- screenshots/05-desktop-cargo-tooltip.png
- screenshots/04-laptop-sigtooltip-1.png

Live URL: https://hormuz-watch-2.pages.dev/
